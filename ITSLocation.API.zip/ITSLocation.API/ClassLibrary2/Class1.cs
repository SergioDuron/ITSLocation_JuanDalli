﻿namespace ClassLibrary2
{
    public class Class1
    {

    }
}
