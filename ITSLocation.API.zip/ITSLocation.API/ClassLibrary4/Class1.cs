﻿namespace ClassLibrary4
{
    public class Class1
    {

    }
}
